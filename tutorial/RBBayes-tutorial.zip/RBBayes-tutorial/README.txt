RBBayes course files

1. Install R and RStudio, plus Rtools (Windows) or Xcode Command Line Tools (macOS).
2. Extract this folder and open RBBayes-tutorial.Rproj in RStudio.
3. Run getwd() in the R Console: it should show this extracted folder.
4. Open install-packages.R and run its commands once, with internet access.
5. Open RBBayes-tutorial.Rmd and run its labelled chunks in order.
   Or open RBBayes-tutorial.R for the plain-script version.

Full setup, worked output and troubleshooting:
https://lapo-santi.github.io/RBBayes/tutorial.html
